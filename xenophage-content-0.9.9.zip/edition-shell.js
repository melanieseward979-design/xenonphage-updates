window.xenoShell = window.xenoShell || undefined;
